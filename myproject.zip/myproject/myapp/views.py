from django.shortcuts import render,redirect
from . models import Employee
# Create your views here.
def index(request):
    emp=Employee.objects.all()
    output={"emp":emp}
    return render(request,"index.html",output)
def reg(request):
    return render(request,"reg.html")
def insert(request):
    empid=request.POST['empid']
    empname=request.POST['empname']
    address=request.POST['address']
    department=request.POST['department']
    salary=request.POST['salary']
    emp=Employee(empid=empid, empname=empname, address=address, department=department, salary=salary)
    emp.save()
    return redirect("index")
def delete(request,eid):
    emp=Employee.objects.get(empid=eid)
    emp.delete()
    return redirect("index")