from django.apps import AppConfig


class OssappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ossapp'
